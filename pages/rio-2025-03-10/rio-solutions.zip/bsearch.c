uint64_t c_bsearch(uint64_t *p, uint64_t x) {
  uint64_t l = 0;
  uint64_t u = 9;
  while (l <= u) {
    uint64_t m = l + ((u - l) / 2);
    if (p[m] < x)
      l = m + 1;
    else if (p[m] > x)
      u = m - 1;
    else
      return m;
  }
  return -1;
}
