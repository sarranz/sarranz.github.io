/* -------------------------------------------------------------------------- */
/* Binary search. */

int compar_uint64_t(const void *a, const void *b) {
  uint64_t x = *(uint64_t *)a;
  uint64_t y = *(uint64_t *)b;
  if (x < y)
    return -1;
  if (x > y)
    return 1;
  return 0;
}

#define BSEARCH_N 10

int test_bsearch(void) {
  uint64_t p[BSEARCH_N];
  rand_fill(p, BSEARCH_N * sizeof(uint64_t));

  // Force a duplicate one in every twenty tests.
  if (0 == rand_uint8_between(0, 20)) {
    p[0] = p[BSEARCH_N - 1];
  }

  uint64_t x = p[rand_uint8_between(0, BSEARCH_N)];

  qsort(p, BSEARCH_N, sizeof(uint64_t), compar_uint64_t);

  uint64_t q[BSEARCH_N];
  memcpy(q, p, BSEARCH_N * sizeof(uint64_t));

  uint64_t c_res = c_bsearch(q, x);
  if (0 != memcmp(p, q, BSEARCH_N * sizeof(uint64_t))) {
    printf("ERROR: C implementation modifies its argument\n");
    for (int i = 0; i < BSEARCH_N; i++) {
      printf("  Argument = %" PRIu64 ", C = %" PRIu64 "\n", p[i], q[i]);
    }
    return 1;
  }

  if (c_res >= BSEARCH_N) {
    printf("ERROR: C result out-of-bounds (returned %" PRIu64 ")\n", c_res);
    return 1;
  }

  uint64_t jazz_res = jazz_bsearch(q, x);
  if (0 != memcmp(p, q, BSEARCH_N * sizeof(uint64_t))) {
    printf("ERROR: JAZZ implementation modifies its argument\n");
    for (int i = 0; i < BSEARCH_N; i++) {
      printf("  Argument = %" PRIu64 ", JAZZ = %" PRIu64 "\n", p[i], q[i]);
    }
    return 1;
  }

  if (jazz_res >= BSEARCH_N) {
    printf("ERROR: JAZZ result out-of-bounds (returned %" PRIu64 ")\n", c_res);
    return 1;
  }

  if (p[c_res] != x) {
    printf("ERROR: C is incorrect\n");
    printf("p =");
    for (int i = 0; i < BSEARCH_N; i++) {
      printf(" %" PRIu64, p[i]);
    }
    printf("\n  x = %" PRIu64 ", C = %" PRIu64 "\n", x, c_res);
    return 1;
  }

  if (p[c_res] != p[jazz_res]) {
    printf("ERROR: JAZZ is incorrect\n");
    printf("p =");
    for (int i = 0; i < BSEARCH_N; i++) {
      printf(" %" PRIu64, p[i]);
    }
    printf("\n  C = %" PRIu64 ", JAZZ = %" PRIu64 "\n", c_res, jazz_res);
    return 1;
  }

  return 0;
}
